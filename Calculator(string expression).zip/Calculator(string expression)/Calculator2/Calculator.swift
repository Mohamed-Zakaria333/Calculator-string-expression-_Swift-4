//
//  ViewController.swift
//  Calculator2
//
//  Created by m on 7/24/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }



}

