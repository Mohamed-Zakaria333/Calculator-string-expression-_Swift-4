//
//  Calc.swift
//  Calculator2
//
//  Created by m on 7/24/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class Calc: UIViewController {
    @IBOutlet weak var BTN_one: UIButton!
    @IBOutlet weak var BTN_tow: UIButton!
    @IBOutlet weak var BTN_three: UIButton!
    @IBOutlet weak var BTN_four: UIButton!
    @IBOutlet weak var BTN_five: UIButton!
    @IBOutlet weak var BTN_six: UIButton!
    @IBOutlet weak var BTN_seven: UIButton!
    @IBOutlet weak var BTN_eight: UIButton!
    @IBOutlet weak var BTN_nine: UIButton!
    @IBOutlet weak var BTN_zero: UIButton!
    @IBOutlet weak var BTN_dot: UIButton!
    @IBOutlet weak var BTN_plus: UIButton!
    @IBOutlet weak var BTN_minus: UIButton!
    @IBOutlet weak var BTN_divid: UIButton!
    @IBOutlet weak var BTN_result: UIButton!
    @IBOutlet weak var BTN_product: UIButton!
    @IBOutlet weak var BTN_moduls: UIButton!
    @IBOutlet weak var txt_input: UITextField!
    @IBOutlet weak var result_label: UILabel!
    @IBOutlet weak var BTN_clear: UIButton!
    
    
    
    //let desinable_button = [BTN_plus,BTN_minus,BTN_divid,BTN_result,BTN_product,BTN_moduls]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txt_input.text = "0.0"
         BTN_result.layer.cornerRadius = 10
         BTN_plus.layer.cornerRadius = 10
         BTN_minus.layer.cornerRadius = 10
         BTN_moduls.layer.cornerRadius = 10
         BTN_product.layer.cornerRadius = 10
         BTN_divid.layer.cornerRadius = 10
         BTN_clear.layer.cornerRadius = 10
        //design(parameter: desinable_button)
        if BTN_six.isTouchInside == true
        {
            
            
        }
        
        
    }
    
    @IBAction func Result(_ sender: UIButton) {
        if (txt_input.text?.last! == "-" || txt_input.text?.last! == "+" || txt_input.text?.last! == "/" || txt_input.text?.last! == "*" || txt_input.text?.last! == "%")
        {
            let  myalert = UIAlertController(title: "Error syntax", message: "correct your syntax", preferredStyle: .alert)
            let myaction = UIAlertAction(title: "ok", style: .cancel, handler: nil)
            myalert.addAction(myaction)
            
            present(myalert, animated: true, completion: nil)
            
            
            
        }
        else
        {
            let operatorss = get_arrays(variable: txt_input.text!).0
            let numberss = get_arrays(variable: txt_input.text!).1
            txt_input.text = String(get_operator_numbers(operators: operatorss, numbers: numberss))
            result_label.text = txt_input.text
            
        }
    }
    
    @IBAction func clear(_ sender: UIButton) {
        txt_input.text = "0.0"
        result_label.text = "0.0"
    }
    @IBAction func write(_ sender: UIButton) {
        if txt_input.text! == "0.0" && (sender.currentTitle! == "+" || sender.currentTitle! == "/" || sender.currentTitle! == "*" || sender.currentTitle! == "%" || sender.currentTitle! == ".")
        {
            
            txt_input.text! = "0.0"
        }
        else if (txt_input.text?.last! == "-" || txt_input.text?.last == "." || txt_input.text?.last! == "+" || txt_input.text?.last! == "/" || txt_input.text?.last! == "*" || txt_input.text?.last! == "%") && (sender.currentTitle! == "+" || sender.currentTitle! == "/" || sender.currentTitle! == "*" || sender.currentTitle! == "%" || sender.currentTitle! == "-" || sender.currentTitle! == "." )
        {
            
            txt_input.text! = txt_input.text!
        }
       else if txt_input.text! == "0.0"
        {
          txt_input.text! = ""
          txt_input.text! += sender.currentTitle!
        }
        else
        {
           txt_input.text! += sender.currentTitle!
            
        }
        
    }
    func design(parameter: [UIButton])
    {
       
         for desinable in parameter
         {
        do {
               desinable.layer.cornerRadius = 10
              // desinable.clipsToBounds = true
                
            }
        }
        
    }
    
    //---------------------------------------------------------------------
    
    func get_arrays(variable: String) -> ([Character],[String])
    {
        var i = 0
        var opera = [Character]()
        var num_str = [String]()
        var index_marker = [Int]()
        //var variable = "-5+10+1245-74*321/417"
        for char in variable {
            
            if (char == "-" && i == 0)
            {}
            else if  ((char == "-" && i != 0) || char == "+" || char == "/" || char == "%" || char == "*")
            {
                opera.append(char)
                index_marker.append(i)
                
            }
            i+=1
            
        }
        index_marker.append(0)
        print(opera)
        print(index_marker)
        func get_str(Str: String,start: Int,end: Int) -> String
        {   // Start with us
            // end don't belong
            let S = Str.index(Str.startIndex, offsetBy: start)
            let E = Str.index(Str.startIndex, offsetBy: end)
            let sub_str1 = S..<E
            let substr = Str[sub_str1]
            let final = String(substr)
            return final
        }
        
        var starting = 0
        var ending = index_marker[0]
        //get_str(Str: variable, start: 10, end: 12)
        for ss in 0...opera.count-1
        {
            num_str.append(get_str(Str: variable, start: starting, end: ending))
            starting = ending+1
            ending = index_marker[ss+1]
        }
        num_str.append(get_str(Str: variable, start: starting, end: variable.count))
        //get_str(Str: myString, start: 10, end: myString.count)
        print(num_str)
        
        return (opera,num_str)
    }
    //****************************************************************************
    func get_operator_numbers(operators: [Character],numbers: [String])-> Double
    {
        var arr = [Double]()
        for elemnt in 0...numbers.count-1
        {
            
            arr.append(Double(numbers[elemnt])!)
            
        }
        print(arr)
        var res = arr[0]
        print (res)
        for elemnt in 0...operators.count-1
        {
            switch operators[elemnt]
            {
            case "+" :
                res += arr[elemnt+1]
                break
            case "-" :
                res -= arr[elemnt+1]
                break
            case "*" :
                res *= arr[elemnt+1]
                break
            case "/" :
                res /= arr[elemnt+1]
                break
            case "%" :
                res = res.truncatingRemainder(dividingBy: arr[elemnt+1])
                break
            default:
                break
                
            }
        }
        return res
    }
   // var operatorss = get_arrays().0
   // var numberss = get_arrays().1
   // get_operator_numbers(operators: operatorss, numbers: numberss)
    //*************************************************************

}
